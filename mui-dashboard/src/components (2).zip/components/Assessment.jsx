import React, { useState, useEffect } from 'react';
import {
  Box,
  Drawer,
  List,
  ListItem,
  ListItemButton,
  ListItemText,
  Typography,
  RadioGroup,
  FormControlLabel,
  Radio,
  Button,
  AppBar,
  Toolbar,
  Avatar,
  Paper,
  Fade,
  CircularProgress,
} from '@mui/material';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

const drawerWidth = 240;

export default function Assessment() {
  const { week, day } = useParams();
  const navigate = useNavigate();
  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    setLoading(true);
    setError(null);
    console.log(`Fetching questions for week ${week} day ${day}`);
    axios
      .get(`http://localhost:5000/api/assessment/${week}/${day}`)
      .then(res => {
        console.log('Response data:', res.data);
        const qs = res.data.questions;
        console.log('Parsed questions:', qs);
        setQuestions(Array.isArray(qs) ? qs : []);
      })
      .catch(err => {
        console.error('Error fetching questions:', err);
        setError('Failed to load questions.');
      })
      .finally(() => setLoading(false));
  }, [week, day]);

  const handleChange = (qIndex, value) => {
    setAnswers(prev => ({ ...prev, [qIndex]: value }));
  };

  const handleSubmit = e => {
    e.preventDefault();
    setSubmitting(true);
    axios
      .post('http://localhost:5000/api/assessment', {
        week: Number(week),
        day: Number(day),
        answers,
        questions,
      })
      .then(res => {
        alert(`You scored ${res.data.score}% on Day ${day}`);
        navigate('/');
      })
      .catch(err => {
        console.error('Submission error:', err);
        alert('Submission failed.');
      })
      .finally(() => setSubmitting(false));
  };

  return (
    <Box sx={{ display: 'flex', bgcolor: '#faf8ff', minHeight: '100vh' }}>
      <Drawer
        variant="permanent"
        sx={{ width: drawerWidth, '& .MuiDrawer-paper': { width: drawerWidth } }}
      >
        <Box sx={{ p: 3 }}>
          <Typography variant="h5" color="primary" fontWeight="bold" gutterBottom>
            <img
              src="/static/success.png"
              alt="Logo"
              style={{ width: 32, height: 32, verticalAlign: 'middle', marginRight: 8 }}
            />
            CampusCareer
          </Typography>
          <List>
            {['Dashboard', 'Communication', 'Assessment'].map(text => (
              <ListItem key={text} disablePadding>
                <ListItemButton
                  selected={text === 'Assessment'}
                  onClick={() => navigate(`/${text.toLowerCase()}`)}
                >
                  <ListItemText
                    primary={text}
                    primaryTypographyProps={{
                      fontWeight: text === 'Assessment' ? 700 : 500,
                      color: text === 'Assessment' ? 'primary' : 'textSecondary',
                    }}
                  />
                </ListItemButton>
              </ListItem>
            ))}
          </List>
        </Box>
      </Drawer>

      <Box component="main" sx={{ flexGrow: 1, p: 4 }}>
        <AppBar position="static" color="transparent" elevation={0}>
          <Toolbar sx={{ justifyContent: 'space-between', mb: 3 }}>
            <Fade in timeout={1000}>
              <Typography variant="h6" sx={{ fontWeight: 500 }}>
                Learn. Grow. Achieve. Your Career, Your Way.
              </Typography>
            </Fade>
            <Avatar src="/static/user.png" />
          </Toolbar>
        </AppBar>

        <Typography variant="body2" color="textSecondary" gutterBottom>
          Dashboard &gt; Assessment
        </Typography>

        <Paper elevation={3} sx={{ borderRadius: 1, p: 4, mt: 2, boxShadow: "0 4px 10px rgba(0,0,0,0.1)" }}>
        <Typography variant="h5" fontWeight="bold" mb={3}>
  Assessment –  <span style={{ color: "#915eff" }}>Week {week}</span>,  <span style={{ color: "#915eff" }}>Day {day}</span>
</Typography>


          {loading ? (
            <Box sx={{ textAlign: 'center', py: 6 }}>
              <CircularProgress />
              <Typography mt={2}>Loading questions...</Typography>
            </Box>
          ) : error ? (
            <Typography color="error">{error}</Typography>
          ) : questions.length === 0 ? (
            <Typography>No questions available for this assessment.</Typography>
          ) : (
            <Box component="form" onSubmit={handleSubmit} sx={{ '& > * + *': { mt: 2, borderColor: "#bea0fe" } }}>
              {questions.map((q, i) => {
                // Normalize options: array, object, or string
                let optionEntries = [];
                if (Array.isArray(q.options)) {
                  optionEntries = q.options.map((opt, idx) => [ ['A','B','C','D'][idx], opt ]);
                } else if (q.options && typeof q.options === 'object') {
                  optionEntries = Object.entries(q.options)
                    .sort((a, b) => a[0].localeCompare(b[0]));
                } else if (typeof q.options === 'string') {
                  optionEntries = q.options.split(',').map((opt, idx) => [ ['A','B','C','D'][idx], opt.trim() ]);
                }

                return (
                  <Paper key={i} variant="outlined" sx={{ p: 3 }}>
                    <Typography variant="subtitle1" gutterBottom>
                      {i + 1}. {q.question}
                    </Typography>
                    <RadioGroup
  name={`q${i}`}
  value={answers[i] || ''}
  onChange={e => handleChange(i, e.target.value)}
  required
>
  {optionEntries.map(([letter, text]) => (
    <FormControlLabel
      key={letter}
      value={letter}
      control={
        <Radio
          sx={{
            '&.Mui-checked': {
              color: '#915eff', // Change selected radio button color to red
            },
          }}
        />
      }
      label={text}
    />
  ))}
</RadioGroup>

                  </Paper>
                );
              })}

              <Box textAlign="center" mt={4}>
                <Button
                  type="submit"
                  variant="contained"
                  size="large"
                  disabled={submitting}
                  sx={{ width: 200, backgroundColor: '#915eff' }}
                >
                  Finish
                </Button>
              </Box>
            </Box>
          )}
        </Paper>
      </Box>
    </Box>
  );
}