import React from 'react'
import Sidebar from './Sidebar'
import Dashboard from './Dashboard'
import { Box } from '@mui/material'

export default function Combine() {
  return (
    <Box display="flex" height="100vh" bgcolor="#f9f9f9">
      <Sidebar />
      <Box component="main" flexGrow={1} p={2} sx={{ marginLeft: 33 }}>
        <Dashboard />
      </Box>
    </Box>
  )
}