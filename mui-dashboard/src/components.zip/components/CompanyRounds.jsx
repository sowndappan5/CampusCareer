// CompanyRounds.jsx
import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Box, Typography, Button } from "@mui/material";

export default function CompanyRounds() {
  const { companyName } = useParams();
  const [rounds, setRounds] = useState(null);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!companyName) {
      setError("No company specified");
      setRounds(null);
      return;
    }

    // Fetch rounds data for the selected company
    fetch(
      `http://localhost:5000/save_company?name=${encodeURIComponent(
        companyName
      )}`
    )
      .then((res) => {
        if (!res.ok) {
          throw new Error("Failed to fetch rounds information");
        }
        return res.json();
      })
      .then((data) => {
        if (!data.rounds) {
          throw new Error("Rounds data not found");
        }
        setRounds(data.rounds);
        setError(null);
      })
      .catch((err) => {
        setError(err.message);
        setRounds(null);
      });
  }, [companyName]);

  const handleGoClick = () => {
    navigate(`/changed`);
  };
  const handleGoClick1 = () => {
    navigate(`/info`);
  };
  return (
    <Box sx={{ p: 3 }}>
      <Button variant="outlined" onClick={() => navigate(-1)} sx={{ mb: 2 }}>
        Back
      </Button>

      <Typography variant="h4" gutterBottom>
        Rounds Information for {companyName}
      </Typography>

      {error && (
        <Typography color="error" variant="body1">
          {error}
        </Typography>
      )}

      {!rounds && !error && <Typography>Loading rounds data...</Typography>}

      {rounds && Object.keys(rounds).length === 0 && (
        <Typography>No rounds information available.</Typography>
      )}

      {rounds &&
        Object.entries(rounds).map(([round, items]) => (
          <Box key={round} sx={{ mb: 3 }}>
            <Typography variant="h6">{round}</Typography>
            {items && items.length > 0 ? (
              <ul>
                {items.map((item, idx) => (
                  <li key={idx}>{item}</li>
                ))}
              </ul>
            ) : (
              <Typography>N/A</Typography>
            )}
          </Box>
        ))}
      <Button
        
        variant="contained"
        sx={{ backgroundColor: "#5c47f5" }}
        onClick={handleGoClick1}
      >
        Go
      </Button>
      <p>Round is changed?</p>
      <Button
        
        variant="contained"
        sx={{ backgroundColor: "#5c47f5" }}
        onClick={handleGoClick}
      >
        Enter round manually
      </Button>
    </Box>
  );
}
