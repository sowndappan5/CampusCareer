import React from "react";
import { Box, Typography, Button } from "@mui/material";

const YouTubeVideos = ({ videoResults }) => (
  <Box>
    {Object.entries(videoResults).map(([query, videos]) => (
      <Box key={query} mb={4}>
        <Typography variant="h6" gutterBottom>
          Suggestions for "{query}"
        </Typography>
        <Box
          sx={{ display: "flex", gap: 3, overflowX: "auto", paddingBottom: 2 }}
        >
          {videos.map((video) => (
            <Box
              key={video.id}
              sx={{
                width: 200,
                flexShrink: 0,
                display: "flex",
                flexDirection: "column",
                p: 2,
                borderRadius: 1,
                boxShadow: "0px 7px 12px rgba(0, 0, 0, 0.1)",
              }}
            >
              <img
                src={video.thumbnail}
                alt={video.title}
                style={{
                  borderRadius: "4px",
                  marginBottom: "8px",
                  width: "100%",
                  height: "auto",
                }}
              />
              <Box
                display="flex"
                flexDirection="column"
                gap={1}
                sx={{ height: "100%" }}
              >
                <Typography variant="subtitle2">{video.title}</Typography>
                <Box sx={{ flexGrow: 1 }} />{" "}
                {/* Spacer to push the button to the bottom */}
                <Button
                  href={video.url}
                  target="_blank"
                  variant="contained"
                  sx={{ backgroundColor: "#1976d2" }}
                >
                  Watch
                </Button>
              </Box>
            </Box>
          ))}
        </Box>
      </Box>
    ))}
  </Box>
);

export default YouTubeVideos;
