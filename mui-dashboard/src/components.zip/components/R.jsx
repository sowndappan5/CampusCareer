// R.jsx
import React, { useState, useRef } from "react";
import {
  Box,
  Grid,
  Typography,
  TextField,
  Button,
  Chip,
  Paper,
  IconButton,
} from "@mui/material";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import { useNavigate } from "react-router-dom";

const tagsList = [
  "Aptitude",
  "Programming",
  "Group Discussion",
  "Long Programming",
  "EEE core concept",
  "MECH core concept",
  "DSA",
  "General HR Questions",
  "JAPANESE related",
  "Computer network",
  "Operating system",
  "Oops",
  "ER Diagram",
];

export default function R() {
  const navigate = useNavigate();
  const [rounds, setRounds] = useState({
    round1: "",
    round2: "",
    round3: "",
    round4: "",
    round5: "",
  });
  const [focusedField, setFocusedField] = useState(null);

  // Handle input focus
  const handleFocus = (field) => {
    setFocusedField(field);
  };

  // Handle tag click: toggle tag in currently focused field
  const handleTagClick = (tag) => {
    if (!focusedField) return;
    const currentTags = rounds[focusedField]
      .split(",")
      .map((t) => t.trim())
      .filter((t) => t);
    const tagIndex = currentTags.indexOf(tag);
    let newTags;
    if (tagIndex > -1) {
      newTags = currentTags.filter((t) => t !== tag);
    } else {
      newTags = [...currentTags, tag];
    }
    setRounds((prev) => ({
      ...prev,
      [focusedField]: newTags.join(", "),
    }));
  };

  // Allow manual typing
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setRounds((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // Submit form to Flask backend
  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new URLSearchParams();
    Object.entries(rounds).forEach(([key, value]) => {
      formData.append(key, value || "N/A");
    });
    try {
      const res = await fetch("http://localhost:5000/changed", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: formData.toString(),
      });
      if (!res.ok) throw new Error("Failed to save rounds");
      navigate("/info");
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <Box
      sx={{
        minHeight: "100vh",
        bgcolor: "#f8f8f8",
        py: 5,
        px: { xs: 1, sm: 4 },
        display: "flex",
        justifyContent: "center",
        alignItems: "flex-start",
      }}
    >
      <Grid
        container
        spacing={4}
        sx={{
          maxWidth: 1200,
          width: "100%",
        }}
      >
        {/* Left Panel: Form */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 4, borderRadius: 2, boxShadow: 2 }}>
            <IconButton onClick={() => navigate(-1)} sx={{ mb: 1 }}>
              <ArrowBackIcon />
            </IconButton>
            <Typography variant="h5" color="primary" fontWeight={600} gutterBottom>
              Round Information
            </Typography>
            <Typography variant="body1" sx={{ mb: 2 }}>
              Customize or update the company's round details based on your college's latest placement process.
            </Typography>
            <Box component="form" onSubmit={handleSubmit} autoComplete="off">
              {["round1", "round2", "round3", "round4", "round5"].map((round, idx) => (
                <TextField
                  key={round}
                  label={`Round ${idx + 1}`}
                  name={round}
                  value={rounds[round]}
                  onFocus={() => handleFocus(round)}
                  onChange={handleInputChange}
                  fullWidth
                  margin="normal"
                  placeholder="Type or click on a tag to fill"
                  multiline
                  minRows={1}
                />
              ))}
              <Button
                variant="contained"
                type="submit"
                fullWidth
                sx={{ mt: 2, bgcolor: "#5a5afc", fontWeight: "bold" }}
              >
                Submit
              </Button>
            </Box>
          </Paper>
        </Grid>
        {/* Right Panel: Tags */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 4, borderRadius: 2, boxShadow: 2 }}>
            <Typography variant="h6" sx={{ mb: 2 }}>
              Tags
            </Typography>
            <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1 }}>
              {tagsList.map((tag) => (
                <Chip
                  key={tag}
                  label={tag}
                  clickable
                  color={
                    focusedField &&
                    rounds[focusedField]
                      .split(",")
                      .map((t) => t.trim())
                      .includes(tag)
                      ? "primary"
                      : "default"
                  }
                  onClick={() => handleTagClick(tag)}
                  sx={{
                    fontSize: 14,
                    borderRadius: 2,
                    px: 2,
                    py: 1,
                  }}
                />
              ))}
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
}
