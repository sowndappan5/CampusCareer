import { Box, Typography, Button } from "@mui/material";
import React from 'react';

const YouTubeVideos = ({ videoResults }) => {
  // Extract the first (and only) query and videos from the object
  const query = Object.keys(videoResults)[0];
  const videos = videoResults[query];

  return (
    <Box>
      {query && videos && (
        <Box key={query}>
          <Typography variant="h6" gutterBottom>
            YouTube Video Suggestions for "<em>{query}</em>"
          </Typography>
          <Box
            sx={{
              display: "flex",
              gap: 4,
              overflowX: "auto",
              paddingBottom: 2,
            }}
          >
            {videos.map((video) => (
              <Box
                key={video.id}
                sx={{
                  width: 200,
                  flexShrink: 0,
                  display: "flex",
                  flexDirection: "column",
                  p: 2,
                  borderRadius: 2,
                  boxShadow: "0px 2px 8px rgba(0, 0, 0, 0.1)",
                }}
              >
                <img
                  src={video.thumbnail}
                  alt="Thumbnail"
                  style={{
                    borderRadius: "4px",
                    marginBottom: "8px",
                    width: "100%",
                    height: "auto",
                  }}
                />
                <Typography variant="subtitle1" sx={{ fontWeight: "medium" }}>
                  {video.title}
                </Typography>
                <Button
                  href={video.url}
                  target="_blank"
                  variant="contained"
                  sx={{ mt: "auto", backgroundColor: "#1976d2" }}
                >
                  Watch Now
                </Button>
              </Box>
            ))}
          </Box>
        </Box>
      )}
    </Box>
  );
};

export default YouTubeVideos;
