import {
  Box,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Collapse,
  Typography,
  Chip,
  Badge,
} from "@mui/material";
import {
  Dashboard,
  People,
  ExpandLess,
  ExpandMore,
  Security,
  Settings,
} from "@mui/icons-material";
import { useState } from "react";

export default function Sidebar() {
  const [openUsers, setOpenUsers] = useState(true);

  return (
    <Box
      width={260}
      height="100vh"
      bgcolor="#fff"
      sx={{
        borderRight: "1px solid #e0e0e0",
        boxShadow: "2px 0 8px rgba(0,0,0,0.03)",
        paddingTop: 2,
      }}
      display="flex"
      flexDirection="column"
      position="fixed"
    >
      <Typography
        variant="h6"
        sx={{
          display: "flex",
          alignItems: "center",
          gap: 1,
          pl: 3,
          pb: 2,
          fontWeight: "bold",
          fontSize: "1.4rem",
          color: "#3b3b3b",
          fontFamily: "Public Sans, sans-serif",
        }}
      >
        <span role="img" aria-label="logo">💪🏻</span> CampusCareer
      </Typography>

      <List component="nav">
        {/* Dashboard with badge */}
        <ListItemButton
          sx={{
            mx: 2,
            borderRadius: 2,
            backgroundColor: "#f0ecfe",
            color: "#5c47f5",
            "&:hover": {
              backgroundColor: "#ebe6fd",
            },
          }}
        >
          <ListItemIcon sx={{ color: "#5c47f5", minWidth: "auto", pl: 1, pr: 2 }}>
            <Dashboard />
          </ListItemIcon>
          <ListItemText primary="Dashboards" />
          <Badge
            badgeContent={5}
            color="error"
            sx={{
              "& .MuiBadge-badge": {
                fontSize: "0.75rem",
                height: "18px",
                minWidth: "18px",
                padding: 0,
              },
            }}
          />
        </ListItemButton>

        {/* Users expandable */}
        <ListItemButton
          sx={{ mx: 2, mt: 1, borderRadius: 2 }}
          onClick={() => setOpenUsers(!openUsers)}
        >
          <ListItemIcon sx={{ minWidth: "auto", pl: 1, pr: 2 }}>
            <People />
          </ListItemIcon>
          <ListItemText primary="Users" />
          {openUsers ? <ExpandLess /> : <ExpandMore />}
        </ListItemButton>

        <Collapse in={openUsers} timeout="auto" unmountOnExit>
          <List component="div" disablePadding>
            <ListItemButton sx={{ pl: 8 }}>
              <ListItemText primary="Overview" />
            </ListItemButton>
            <ListItemButton sx={{ pl: 8 }}>
              <ListItemText primary="Security" />
            </ListItemButton>
          </List>
        </Collapse>

        {/* Billing */}
        <ListItemButton sx={{ mx: 2, mt: 1, borderRadius: 2 }}>
          <ListItemIcon sx={{ minWidth: "auto", pl: 1, pr: 2 }}>
            <Settings />
          </ListItemIcon>
          <ListItemText primary="Billing & Plans" />
        </ListItemButton>

        {/* Connection with 'PRO' chip */}
        <ListItemButton sx={{ mx: 2, mt: 1, borderRadius: 2 }}>
          <ListItemIcon sx={{ minWidth: "auto", pl: 1, pr: 2 }}>
            <Security />
          </ListItemIcon>
          <ListItemText primary="Front Pages" />
          <Chip
            label="PRO"
            size="small"
            sx={{
              bgcolor: "#ebe6fd",
              color: "#5c47f5",
              fontWeight: 600,
              fontSize: "0.65rem",
              ml: 1,
            }}
          />
        </ListItemButton>
      </List>
    </Box>
  );
}
