import React from "react";
import {
  AppBar,
  Toolbar,
  IconButton,
  InputBase,
  Badge,
  Typography,
  Avatar,
  Box,
  Grid,
  Paper,
  useTheme,
} from "@mui/material";
import { styled, alpha } from "@mui/material/styles";
import SearchIcon from "@mui/icons-material/Search";
import NotificationsNoneOutlinedIcon from "@mui/icons-material/NotificationsNoneOutlined";
import StarOutlineIcon from "@mui/icons-material/StarOutline";
import Brightness4Icon from "@mui/icons-material/Brightness4";
import Brightness7Icon from "@mui/icons-material/Brightness7";

const cardStyle = {
  p: 2,
  borderRadius: 2,
  height: "100%",
  boxShadow: "0 2px 10px rgba(0,0,0,0.05)",
  backgroundColor: "#ffff",
};

const Search = styled("div")(({ theme }) => ({
    position: "relative",
    borderRadius: theme.shape.borderRadius,
    // Remove backgroundColor for transparency
    backgroundColor: "transparent",
    "&:hover": {
      backgroundColor: "transparent", // No background on hover
    },
    width: "100%",
    maxWidth: 400, // or your preferred width
    display: "flex",
    alignItems: "center",
    border: "none", // Remove border if you want no outline
  }));
  

const SearchIconWrapper = styled("div")(({ theme }) => ({
  marginRight: theme.spacing(1),
  color: theme.palette.text.secondary,
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: "inherit",
  flex: 1,
}));

export default function College({ toggleTheme, mode }) {
  const theme = useTheme();

  return (
    <Grid container spacing={2}>
        <AppBar position="static" color="default" elevation={0} sx={{ p: 1 }}>
      <Toolbar sx={{ justifyContent: "space-between" }}>
        {/* Search */}
        <Search>
          <SearchIconWrapper>
            <SearchIcon />
          </SearchIconWrapper>
          <StyledInputBase
            placeholder="Search..."
            inputProps={{ "aria-label": "search" }}
          />
        </Search>

        {/* Right Section */}
        <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
          <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
            <StarOutlineIcon color="warning" />
            <Typography variant="subtitle2" fontWeight="bold">
              1.8k
            </Typography>
          </Box>

          <IconButton onClick={toggleTheme}>
            {mode === "dark" ? <Brightness7Icon /> : <Brightness4Icon />}
          </IconButton>

          <IconButton>
            <Badge color="error" variant="dot">
              <NotificationsNoneOutlinedIcon />
            </Badge>
          </IconButton>

          <Avatar
            alt="Profile"
            src="https://i.pravatar.cc/300"
            sx={{ width: 32, height: 32 }}
          />
        </Box>
      </Toolbar>
      
    </AppBar>
    <Grid item xs={12} md={8}>
        <Paper
          sx={{
            ...cardStyle,
            height: 600,
            width: 700,
            display: "flex",
            alignItems: "left",
            flexDirection: "column",
            gap: 1,
            borderRadius: 1,
            boxShadow: "0px 4px 12px rgba(0, 0, 0, 0.1)",
            position: "relative", // Ensures absolute positioning inside
          }}
        >
          <Box
            component="img"
            src="/icons/apartment.png"
            alt="fire icon"
            sx={{ width: 50, height: 50 }}
          />
          <Typography variant="h6" sx={{ color: "#555" }}>
            Drive Countdown
          </Typography>
          <Typography variant="h4" sx={{ fontWeight: "bold", color: "#555" }}>
            days
          </Typography>
        </Paper>
      </Grid>
      <Grid item xs={12} md={8}>
        <Paper
          sx={{
            ...cardStyle,
            height: 600,
            width: 450,
            display: "flex",
            alignItems: "left",
            flexDirection: "column",
            gap: 1,
            borderRadius: 1,
            boxShadow: "0px 4px 12px rgba(0, 0, 0, 0.1)",
            position: "relative", // Ensures absolute positioning inside
          }}
        >
          <Box
            component="img"
            src="/icons/apartment.png"
            alt="fire icon"
            sx={{ width: 50, height: 50 }}
          />
          <Typography variant="h6" sx={{ color: "#555" }}>
            Drive Countdown
          </Typography>
          <Typography variant="h4" sx={{ fontWeight: "bold", color: "#555" }}>
            days
          </Typography>
        </Paper>
      </Grid>
    </Grid>
    
  );
}
