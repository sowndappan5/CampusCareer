// src/pages/LoginPage.jsx
import { useState } from 'react'
import {
  Box, Button, Card, CardContent, Checkbox, Divider,
  FormControl, FormControlLabel, IconButton, InputAdornment,
  InputLabel, OutlinedInput, TextField, Typography
} from '@mui/material'
import { styled } from '@mui/material/styles'

import GoogleIcon from '@mui/icons-material/Google';
import GitHubIcon from '@mui/icons-material/GitHub';
import TwitterIcon from '@mui/icons-material/Twitter';
import FacebookIcon from '@mui/icons-material/Facebook';

import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';

import { useNavigate } from 'react-router-dom'
import BlankLayout from './BlankLayout'
import FooterIllustrationsV1 from './FooterIllustration'

const LinkStyled = styled('a')(({ theme }) => ({
  fontSize: '0.875rem',
  textDecoration: 'none',
  color: theme.palette.primary.main,
  cursor: 'pointer'
}))

const LoginPage = () => {
  const [values, setValues] = useState({
    password: '',
    showPassword: false
  })

  const navigate = useNavigate()

  const handleChange = prop => event => {
    setValues({ ...values, [prop]: event.target.value })
  }

  const handleClickShowPassword = () => {
    setValues({ ...values, showPassword: !values.showPassword })
  }

  return (
    <Box className='content-center' sx={{ minHeight: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
      <Card sx={{ width: '28rem', zIndex: 1 }}>
        <CardContent sx={{ p: 6 }}>
          <Typography variant='h5' sx={{ mb: 4 }}>Welcome! 👋🏻</Typography>
          <Typography variant='body2' sx={{ mb: 4 }}>Please sign in to continue</Typography>
          <form onSubmit={e => e.preventDefault()}>
            <TextField fullWidth label='Email' sx={{ mb: 4 }} />
            <FormControl fullWidth>
              <InputLabel>Password</InputLabel>
              <OutlinedInput
                type={values.showPassword ? 'text' : 'password'}
                value={values.password}
                onChange={handleChange('password')}
                endAdornment={
                  <InputAdornment position='end'>
                    <IconButton
                      onClick={handleClickShowPassword}
                      edge='end'
                    >
                      {values.showPassword ? <Visibility /> : <VisibilityOff />}

                    </IconButton>
                  </InputAdornment>
                }
              />
            </FormControl>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 2, mb: 4 }}>
              <FormControlLabel control={<Checkbox />} label='Remember Me' />
              <LinkStyled onClick={() => alert('Forgot password clicked')}>Forgot Password?</LinkStyled>
            </Box>
            <Button fullWidth variant='contained' onClick={() => navigate('/')}>Login</Button>
            <Box sx={{ mt: 4, textAlign: 'center' }}>
              <Typography variant='body2'>
                New here? <LinkStyled onClick={() => navigate('/register')}>Create an account</LinkStyled>
              </Typography>
            </Box>
            <Divider sx={{ my: 5 }}>or</Divider>
            <Box sx={{ display: 'flex', justifyContent: 'center', gap: 2 }}>
              <IconButton><FacebookIcon sx={{ color: '#497ce2' }} /></IconButton>
              <IconButton><TwitterIcon sx={{ color: '#1da1f2' }} /></IconButton>
              <IconButton><GitHubIcon sx={{ color: '#272727' }} /></IconButton>
              <IconButton><GoogleIcon sx={{ color: '#db4437' }} /></IconButton>
            </Box>
          </form>
        </CardContent>
      </Card>
      <FooterIllustrationsV1 />
    </Box>
  )
}
LoginPage.getLayout = page => <BlankLayout>{page}</BlankLayout>

export default LoginPage
